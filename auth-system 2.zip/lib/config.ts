// Configuración centralizada para variables de entorno

// Autenticación
export const AUTH_CONFIG = {
  // Credenciales de administrador
  adminUsername: process.env.ADMIN_USERNAME || "CyberMorsa",
  adminPassword: process.env.ADMIN_PASSWORD || "CyberMorsa",

  // Credenciales de invitado
  guestUsername: process.env.GUEST_USERNAME || "CyberGuest",
  guestPassword: process.env.GUEST_PASSWORD || "CyberGuest",

  // JWT
  jwtSecret: process.env.JWT_SECRET || "Morsaletal2.0",
  jwtExpiresIn: "24h",
}

// Base de datos
export const DB_CONFIG = {
  url: process.env.DATABASE_URL || "",
}

// Función para verificar si las variables de entorno están configuradas
export function checkEnvVars() {
  const missingVars = []

  if (!process.env.ADMIN_USERNAME) missingVars.push("ADMIN_USERNAME")
  if (!process.env.ADMIN_PASSWORD) missingVars.push("ADMIN_PASSWORD")
  if (!process.env.GUEST_USERNAME) missingVars.push("GUEST_USERNAME")
  if (!process.env.GUEST_PASSWORD) missingVars.push("GUEST_PASSWORD")
  if (!process.env.JWT_SECRET) missingVars.push("JWT_SECRET")
  if (!process.env.DATABASE_URL) missingVars.push("DATABASE_URL")

  return {
    allConfigured: missingVars.length === 0,
    missingVars,
  }
}

// Función para obtener información de depuración sobre las variables de entorno
export function getEnvDebugInfo() {
  return {
    adminUsername: AUTH_CONFIG.adminUsername,
    adminPasswordSet: !!process.env.ADMIN_PASSWORD,
    guestUsername: AUTH_CONFIG.guestUsername,
    guestPasswordSet: !!process.env.GUEST_PASSWORD,
    jwtSecretSet: !!process.env.JWT_SECRET,
    databaseUrlSet: !!process.env.DATABASE_URL,
  }
}
