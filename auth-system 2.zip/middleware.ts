import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { jwtVerify } from "jose"
import { AUTH_CONFIG } from "./lib/config"

// Rutas que requieren autenticación
const protectedRoutes = ["/dashboard"]

// Rutas públicas
const publicRoutes = ["/login", "/api/auth/login"]

// Secret key for JWT verification
const JWT_SECRET = new TextEncoder().encode(AUTH_CONFIG.jwtSecret)

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname

  // Si es una ruta pública, permitir acceso
  if (publicRoutes.some((route) => path.startsWith(route))) {
    return NextResponse.next()
  }

  // Si es una ruta protegida, verificar autenticación
  if (protectedRoutes.some((route) => path.startsWith(route))) {
    const token = request.cookies.get("auth-token")?.value

    // Si no hay token, redirigir a login
    if (!token) {
      const url = new URL("/login", request.url)
      url.searchParams.set("from", path)
      return NextResponse.redirect(url)
    }

    try {
      // Verificar token
      await jwtVerify(token, JWT_SECRET)
      return NextResponse.next()
    } catch (error) {
      console.error("Error al verificar token:", error)
      // Token inválido, redirigir a login
      const url = new URL("/login", request.url)
      url.searchParams.set("from", path)
      return NextResponse.redirect(url)
    }
  }

  // Para otras rutas, permitir acceso
  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
}
