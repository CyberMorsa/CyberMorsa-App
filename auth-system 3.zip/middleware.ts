import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Rutas protegidas
const protectedPaths = ["/dashboard"]

// Rutas públicas
const publicPaths = ["/login", "/api/auth/login"]

export function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname

  // Si es una ruta pública, permitir acceso
  if (publicPaths.some((p) => path.startsWith(p))) {
    return NextResponse.next()
  }

  // Si es una ruta protegida, verificar token
  if (protectedPaths.some((p) => path.startsWith(p))) {
    const token = request.cookies.get("auth-token")

    if (!token) {
      // Redirigir a login si no hay token
      return NextResponse.redirect(new URL("/login", request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
}
