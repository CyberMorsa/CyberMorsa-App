import { checkEnvVars } from "./config"

// Verificar variables de entorno al iniciar la aplicación
function checkEnvironmentVariables() {
  const { allConfigured, missingVars } = checkEnvVars()

  if (!allConfigured) {
    console.warn("⚠️ ADVERTENCIA: Faltan las siguientes variables de entorno:", missingVars.join(", "))
    console.warn("La aplicación utilizará valores predeterminados para las variables faltantes.")
  } else {
    console.log("✅ Todas las variables de entorno están configuradas correctamente.")
  }
}

// Ejecutar verificación
checkEnvironmentVariables()
