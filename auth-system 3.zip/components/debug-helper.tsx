"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"

export function DebugHelper() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [envInfo, setEnvInfo] = useState<any>(null)

  const checkEnv = async () => {
    setLoading(true)
    setError("")

    try {
      const response = await fetch("/api/debug/env")

      if (!response.ok) {
        throw new Error("Error al obtener información de variables de entorno")
      }

      const data = await response.json()
      setEnvInfo(data)
    } catch (err) {
      console.error("Error:", err)
      setError("Error al verificar variables de entorno")
    } finally {
      setLoading(false)
    }
  }

  // Solo mostrar en desarrollo
  if (process.env.NODE_ENV === "production") {
    return null
  }

  return (
    <Card className="mt-8 w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-xl">Herramienta de Depuración</CardTitle>
      </CardHeader>
      <CardContent>
        <Button onClick={checkEnv} disabled={loading} variant="outline" className="w-full">
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Verificando...
            </>
          ) : (
            "Verificar Variables de Entorno"
          )}
        </Button>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {envInfo && (
          <div className="mt-4 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
            <h3 className="font-medium mb-2">Estado de Variables de Entorno:</h3>
            <pre className="text-xs overflow-auto p-2 bg-gray-200 dark:bg-gray-900 rounded">
              {JSON.stringify(envInfo, null, 2)}
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
