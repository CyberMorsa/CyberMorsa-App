import { LoginForm } from "@/components/login-form"
import { DebugHelper } from "@/components/debug-helper"

export default function LoginPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-b from-gray-900 to-gray-800">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white">CyberMorsa</h1>
          <p className="text-gray-400 mt-2">Plataforma de Ciberseguridad y OSINT</p>
        </div>

        <LoginForm />

        {/* Solo mostrar en desarrollo */}
        {process.env.NODE_ENV !== "production" && <DebugHelper />}
      </div>
    </div>
  )
}
