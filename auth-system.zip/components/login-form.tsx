"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Info } from "lucide-react"

export function LoginForm() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [debugInfo, setDebugInfo] = useState<any>(null)
  const router = useRouter()

  // Limpiar errores cuando cambian las credenciales
  useEffect(() => {
    if (error) setError("")
  }, [username, password])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)
    setDebugInfo(null)

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      })

      const data = await response.json()

      if (data.success) {
        router.push("/dashboard")
      } else {
        setError(data.error || "Credenciales inválidas")
        // Mostrar información de depuración en desarrollo
        if (process.env.NODE_ENV !== "production" && data.debug) {
          setDebugInfo(data.debug)
        }
      }
    } catch (err) {
      console.error("Error al iniciar sesión:", err)
      setError("Error al conectar con el servidor")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl">Iniciar Sesión</CardTitle>
        <CardDescription>Ingresa tus credenciales para acceder al sistema</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username">Usuario</Label>
            <Input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              autoComplete="username"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Contraseña</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />
          </div>
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Iniciando sesión...
              </>
            ) : (
              "Iniciar Sesión"
            )}
          </Button>
        </form>

        {/* Información de ayuda */}
        <div className="mt-4 text-sm text-muted-foreground">
          <p>Si tienes problemas para iniciar sesión:</p>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Verifica que las variables de entorno estén configuradas correctamente</li>
            <li>Asegúrate de usar las credenciales exactas (sensible a mayúsculas/minúsculas para contraseñas)</li>
          </ul>
        </div>

        {/* Información de depuración (solo en desarrollo) */}
        {debugInfo && (
          <div className="mt-4 p-3 bg-blue-500/20 border border-blue-500/50 rounded-lg text-sm text-blue-200">
            <div className="flex items-center gap-2 mb-1">
              <Info className="h-4 w-4" />
              <span className="font-medium">Información de depuración</span>
            </div>
            <pre className="whitespace-pre-wrap">{JSON.stringify(debugInfo, null, 2)}</pre>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-center text-sm text-muted-foreground">
        <p>Credenciales por defecto: admin / admin123 o guest / guest123</p>
      </CardFooter>
    </Card>
  )
}
