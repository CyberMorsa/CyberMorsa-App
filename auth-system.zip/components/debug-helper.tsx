"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"

export function DebugHelper() {
  const [envInfo, setEnvInfo] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const checkEnv = async () => {
    setLoading(true)
    setError("")
    try {
      const res = await fetch("/api/debug/env")
      if (res.ok) {
        const data = await res.json()
        setEnvInfo(data)
      } else {
        setError("No se pudo obtener la información de variables de entorno")
      }
    } catch (err) {
      setError("Error al conectar con el servidor")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="mt-4">
      <CardHeader>
        <CardTitle className="text-lg">Herramienta de Depuración</CardTitle>
      </CardHeader>
      <CardContent>
        <Button onClick={checkEnv} disabled={loading} variant="outline" size="sm">
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Verificando...
            </>
          ) : (
            "Verificar Variables de Entorno"
          )}
        </Button>

        {error && <p className="mt-2 text-red-500 text-sm">{error}</p>}

        {envInfo && (
          <div className="mt-4 p-3 bg-gray-100 dark:bg-gray-800 rounded-lg text-sm">
            <h3 className="font-medium mb-2">Variables de Entorno:</h3>
            <pre className="whitespace-pre-wrap">{JSON.stringify(envInfo, null, 2)}</pre>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
